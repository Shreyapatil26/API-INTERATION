
import React, { useState, useEffect } from 'react';
import { Product } from '../types';
import { generateProductPitch } from '../services/geminiService';

interface ProductModalProps {
  product: Product | null;
  onClose: () => void;
  onAddToCart: (product: Product) => void;
}

const ProductModal: React.FC<ProductModalProps> = ({ product, onClose, onAddToCart }) => {
  const [aiPitch, setAiPitch] = useState<string>('');
  const [loadingPitch, setLoadingPitch] = useState(false);

  useEffect(() => {
    if (product) {
      setLoadingPitch(true);
      generateProductPitch(product).then(pitch => {
        setAiPitch(pitch || product.description);
        setLoadingPitch(false);
      });
    }
  }, [product]);

  if (!product) return null;

  return (
    <div className="fixed inset-0 z-[60] flex items-center justify-center p-4">
      <div className="absolute inset-0 bg-slate-900/60 backdrop-blur-md" onClick={onClose} />
      
      <div className="relative w-full max-w-5xl bg-white rounded-[2.5rem] overflow-hidden shadow-2xl animate-in zoom-in duration-300">
        <button 
          onClick={onClose}
          className="absolute right-6 top-6 z-10 p-2 bg-white/80 hover:bg-white rounded-full shadow-lg text-slate-900 transition-all"
        >
          <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
          </svg>
        </button>

        <div className="flex flex-col md:flex-row">
          <div className="w-full md:w-1/2 h-[400px] md:h-auto overflow-hidden">
            <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
          </div>
          
          <div className="w-full md:w-1/2 p-8 md:p-12 flex flex-col">
            <div className="flex-1">
              <span className="inline-block px-3 py-1 bg-indigo-50 text-indigo-600 text-[10px] font-bold rounded-full mb-6 border border-indigo-100 uppercase tracking-widest">
                {product.category}
              </span>
              <h2 className="text-4xl font-bold text-slate-900 mb-4 leading-tight">{product.name}</h2>
              <div className="flex items-center gap-2 mb-8">
                <div className="flex text-yellow-400">
                  {[...Array(5)].map((_, i) => (
                    <span key={i} className={i < Math.floor(product.rating) ? 'text-yellow-400' : 'text-slate-200'}>★</span>
                  ))}
                </div>
                <span className="text-sm font-medium text-slate-500">({product.rating} / 5.0)</span>
              </div>

              <div className="bg-slate-50 rounded-2xl p-6 mb-8 border border-slate-100">
                <div className="flex items-center gap-2 mb-3">
                  <span className="text-indigo-600">
                    <svg className="w-4 h-4" fill="currentColor" viewBox="0 0 20 20">
                      <path d="M10 12a2 2 0 100-4 2 2 0 000 4z" />
                      <path fillRule="evenodd" d="M.458 10C1.732 5.943 5.522 3 10 3s8.268 2.943 9.542 7c-1.274 4.057-5.064 7-9.542 7S1.732 14.057.458 10zM14 10a4 4 0 11-8 0 4 4 0 018 0z" clipRule="evenodd" />
                    </svg>
                  </span>
                  <span className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">Expert Insight</span>
                </div>
                {loadingPitch ? (
                  <div className="space-y-2">
                    <div className="h-4 bg-slate-200 rounded-full w-full animate-pulse" />
                    <div className="h-4 bg-slate-200 rounded-full w-2/3 animate-pulse" />
                  </div>
                ) : (
                  <p className="text-slate-700 italic leading-relaxed">"{aiPitch}"</p>
                )}
              </div>

              <div className="mb-8">
                <h4 className="text-sm font-bold text-slate-900 mb-3 uppercase tracking-wider">Details</h4>
                <p className="text-slate-600 leading-relaxed">{product.description}</p>
              </div>
            </div>

            <div className="pt-8 border-t border-slate-100 flex items-center justify-between">
              <div>
                <p className="text-slate-400 text-sm mb-1 uppercase tracking-wider font-semibold">Price</p>
                <p className="text-3xl font-bold text-slate-900">${product.price.toLocaleString()}</p>
              </div>
              <button 
                onClick={() => onAddToCart(product)}
                className="px-10 py-4 bg-indigo-600 text-white rounded-2xl font-bold text-lg hover:bg-indigo-700 transition-all shadow-xl shadow-indigo-200 flex items-center gap-3"
              >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M16 11V7a4 4 0 00-8 0v4M5 9h14l1 12H4L5 9z" />
                </svg>
                Add to Bag
              </button>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default ProductModal;
