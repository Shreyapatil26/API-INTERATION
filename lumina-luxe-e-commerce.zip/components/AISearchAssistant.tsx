
import React, { useState, useEffect } from 'react';
import { getSmartRecommendations } from '../services/geminiService';
import { Product, SearchRecommendation } from '../types';
import { products } from '../data/products';

interface AISearchAssistantProps {
  onRecommendationSelect: (product: Product) => void;
}

const AISearchAssistant: React.FC<AISearchAssistantProps> = ({ onRecommendationSelect }) => {
  const [query, setQuery] = useState('');
  const [loading, setLoading] = useState(false);
  const [results, setResults] = useState<{productId: string, reason: string}[]>([]);
  const [isFocused, setIsFocused] = useState(false);

  useEffect(() => {
    if (!query || query.length < 3) {
      setResults([]);
      return;
    }

    const timer = setTimeout(async () => {
      setLoading(true);
      const recommendations = await getSmartRecommendations(query, products);
      setResults(recommendations);
      setLoading(false);
    }, 800);

    return () => clearTimeout(timer);
  }, [query]);

  return (
    <div className="relative w-full max-w-2xl mx-auto">
      <div className={`relative group transition-all duration-300 ${isFocused ? 'scale-105' : ''}`}>
        <div className="absolute inset-y-0 left-0 pl-4 flex items-center pointer-events-none">
          <svg className={`h-5 w-5 ${loading ? 'animate-spin text-indigo-500' : 'text-slate-400'}`} fill="none" viewBox="0 0 24 24" stroke="currentColor">
            {loading ? (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M4 4v5h.582m15.356 2A8.001 8.001 0 004.582 9m0 0H9m11 11v-5h-.581m0 0a8.003 8.003 0 01-15.357-2m15.357 2H15" />
            ) : (
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
            )}
          </svg>
        </div>
        <input
          type="text"
          value={query}
          onChange={(e) => setQuery(e.target.value)}
          onFocus={() => setIsFocused(true)}
          onBlur={() => setTimeout(() => setIsFocused(false), 200)}
          placeholder="Ask Lumina AI... (e.g., 'Something for my home office')"
          className="block w-full pl-12 pr-4 py-4 bg-white border-2 border-slate-100 rounded-3xl text-slate-900 placeholder:text-slate-400 focus:outline-none focus:border-indigo-500 focus:ring-4 focus:ring-indigo-50/50 transition-all shadow-sm"
        />
        <div className="absolute right-3 inset-y-0 flex items-center">
            <span className="bg-indigo-50 text-indigo-600 text-[10px] font-bold px-2 py-1 rounded-full border border-indigo-100">AI ENHANCED</span>
        </div>
      </div>

      {isFocused && (results.length > 0 || loading) && (
        <div className="absolute z-50 mt-4 w-full bg-white rounded-3xl shadow-2xl border border-slate-100 overflow-hidden animate-in fade-in slide-in-from-top-4 duration-300">
          <div className="p-4 border-b border-slate-50 bg-slate-50/50">
            <h4 className="text-[10px] font-bold text-slate-400 uppercase tracking-widest">AI Recommendations</h4>
          </div>
          <div className="p-2 space-y-1">
            {loading ? (
              <div className="py-8 flex flex-col items-center justify-center text-slate-400 gap-3">
                <div className="flex gap-1">
                    <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.3s]"></div>
                    <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce [animation-delay:-0.15s]"></div>
                    <div className="w-1.5 h-1.5 bg-indigo-400 rounded-full animate-bounce"></div>
                </div>
                <span className="text-xs font-medium">Lumina is thinking...</span>
              </div>
            ) : (
              results.map((res) => {
                const product = products.find(p => p.id === res.productId);
                if (!product) return null;
                return (
                  <button
                    key={res.productId}
                    onClick={() => onRecommendationSelect(product)}
                    className="w-full text-left p-4 hover:bg-slate-50 rounded-2xl flex items-start gap-4 transition-colors group"
                  >
                    <div className="w-12 h-12 rounded-xl bg-slate-100 overflow-hidden flex-shrink-0">
                      <img src={product.image} alt={product.name} className="w-full h-full object-cover" />
                    </div>
                    <div>
                      <h5 className="font-bold text-slate-900 text-sm group-hover:text-indigo-600">{product.name}</h5>
                      <p className="text-xs text-slate-500 leading-relaxed mt-0.5">{res.reason}</p>
                    </div>
                  </button>
                );
              })
            )}
          </div>
        </div>
      )}
    </div>
  );
};

export default AISearchAssistant;
