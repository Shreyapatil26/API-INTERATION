
import React from 'react';
import { Product } from '../types';

interface ProductCardProps {
  product: Product;
  onSelect: (product: Product) => void;
  onAddToCart: (product: Product) => void;
}

const ProductCard: React.FC<ProductCardProps> = ({ product, onSelect, onAddToCart }) => {
  return (
    <div className="group bg-white rounded-2xl border border-slate-100 overflow-hidden transition-all duration-300 hover:shadow-xl hover:-translate-y-1">
      <div 
        className="aspect-[4/5] overflow-hidden cursor-pointer relative"
        onClick={() => onSelect(product)}
      >
        <img 
          src={product.image} 
          alt={product.name} 
          className="w-full h-full object-cover transition-transform duration-500 group-hover:scale-110"
        />
        <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors duration-300" />
      </div>
      
      <div className="p-5">
        <div className="flex justify-between items-start mb-1">
          <p className="text-xs font-semibold uppercase tracking-wider text-slate-400">{product.category}</p>
          <div className="flex items-center gap-1">
            <span className="text-yellow-400 text-sm">★</span>
            <span className="text-xs font-medium text-slate-600">{product.rating}</span>
          </div>
        </div>
        
        <h3 
          className="text-lg font-bold text-slate-900 mb-2 cursor-pointer hover:text-indigo-600 transition-colors line-clamp-1"
          onClick={() => onSelect(product)}
        >
          {product.name}
        </h3>
        
        <div className="flex items-center justify-between mt-4">
          <p className="text-xl font-bold text-slate-900">
            ${product.price.toLocaleString(undefined, { minimumFractionDigits: 2 })}
          </p>
          <button 
            onClick={() => onAddToCart(product)}
            className="p-2.5 bg-slate-900 text-white rounded-xl hover:bg-indigo-600 transition-colors"
            title="Add to Cart"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
              <path d="M3 1a1 1 0 000 2h1.22l.305 1.222a.997.997 0 00.01.042l1.358 5.43-.893.892C3.74 11.846 4.632 14 6.414 14H15a1 1 0 100-2H6.414l1-1H14a1 1 0 00.894-.553l3-6A1 1 0 0017 3H6.28l-.31-1.243A1 1 0 005 1H3zM16 16.5a1.5 1.5 0 11-3 0 1.5 1.5 0 013 0zM6.5 18a1.5 1.5 0 100-3 1.5 1.5 0 000 3z" />
            </svg>
          </button>
        </div>
      </div>
    </div>
  );
};

export default ProductCard;
