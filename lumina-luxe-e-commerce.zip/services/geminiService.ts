
import { GoogleGenAI, Type } from "@google/genai";
import { Product } from "../types";

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY || '' });

export const getSmartRecommendations = async (query: string, availableProducts: Product[]) => {
  const model = 'gemini-3-flash-preview';
  
  const productContext = availableProducts.map(p => 
    `ID: ${p.id}, Name: ${p.name}, Category: ${p.category}, Description: ${p.description}`
  ).join('\n');

  try {
    const response = await ai.models.generateContent({
      model,
      contents: `User is searching for: "${query}". Based on the following inventory, recommend 3 relevant products and explain why.
      
      Inventory:
      ${productContext}`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              productId: { type: Type.STRING },
              reason: { type: Type.STRING }
            },
            required: ["productId", "reason"]
          }
        }
      }
    });

    return JSON.parse(response.text || '[]');
  } catch (error) {
    console.error("AI Recommendation Error:", error);
    return [];
  }
};

export const generateProductPitch = async (product: Product) => {
  const model = 'gemini-3-flash-preview';
  try {
    const response = await ai.models.generateContent({
      model,
      contents: `Write a compelling, luxury-focused sales pitch (max 2 sentences) for the product "${product.name}" described as "${product.description}".`,
    });
    return response.text;
  } catch (error) {
    return product.description;
  }
};
