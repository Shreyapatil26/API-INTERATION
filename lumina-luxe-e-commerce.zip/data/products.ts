
import { Product } from '../types';

export const products: Product[] = [
  {
    id: '1',
    name: 'Aether S1 Noise Cancelling Headphones',
    category: 'Electronics',
    price: 349.99,
    description: 'Experience pure sonic bliss with industry-leading noise cancellation and spatial audio technology.',
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&q=80&w=600',
    rating: 4.8,
    stock: 12
  },
  {
    id: '2',
    name: 'Nordic Oak Minimalist Desk',
    category: 'Furniture',
    price: 899.00,
    description: 'Sustainably sourced solid oak desk with integrated cable management and a silk-smooth finish.',
    image: 'https://images.unsplash.com/photo-1518455027359-f3f8164ba6bd?auto=format&fit=crop&q=80&w=600',
    rating: 4.9,
    stock: 5
  },
  {
    id: '3',
    name: 'Nebula 4K Smart Projector',
    category: 'Electronics',
    price: 1299.00,
    description: 'Transform any room into a cinematic masterpiece with ultra-short throw laser projection.',
    image: 'https://images.unsplash.com/photo-1535016120720-40c646be44da?auto=format&fit=crop&q=80&w=600',
    rating: 4.7,
    stock: 8
  },
  {
    id: '4',
    name: 'Suede Chelsea Boots',
    category: 'Apparel',
    price: 195.00,
    description: 'Handcrafted Italian suede boots with a durable Goodyear welt and timeless silhouette.',
    image: 'https://images.unsplash.com/photo-1560769629-975ec94e6a86?auto=format&fit=crop&q=80&w=600',
    rating: 4.6,
    stock: 24
  },
  {
    id: '5',
    name: 'Zenith Automatic Watch',
    category: 'Apparel',
    price: 2450.00,
    description: 'A precision-engineered timepiece with an open-heart skeleton dial and sapphire crystal.',
    image: 'https://images.unsplash.com/photo-1524592094714-0f0654e20314?auto=format&fit=crop&q=80&w=600',
    rating: 5.0,
    stock: 3
  },
  {
    id: '6',
    name: 'Lumina Smart Table Lamp',
    category: 'Lighting',
    price: 149.00,
    description: 'Adaptive lighting that syncs with your circadian rhythm, featuring touch-capacitive controls.',
    image: 'https://images.unsplash.com/photo-1507473885765-e6ed657f9971?auto=format&fit=crop&q=80&w=600',
    rating: 4.5,
    stock: 45
  }
];
